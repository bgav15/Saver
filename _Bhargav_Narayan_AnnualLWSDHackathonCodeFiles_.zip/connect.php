<!DOCTYPE html>
<html>
<head>
  <title>Connect to devices</title>
</head>
<style>
</style>
<body>
  <!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<title>Saver</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
	 crossorigin="anonymous">


	<style>
		.content {
			display: none;
			margin: 1em;
		}
	</style>

</head>

<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<a class="navbar-brand" href="#">Saver</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="buy.php">Buy Devices</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="connect.php">Connect to Device(s)</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
    </ul>
  </div>
  </nav>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
      

  
  <script>
    hideScreens();


    function hideScreens() {
      $(".content").hide();
    }


    $(document).ready(function() {



      $(".nav-link").on("click", function(){
        hideScreens();
        var target = $(this).attr("href");
        $(target).show();
        $(target).load("page_content/_" + target.replace("#","") + ".html");
      });

    });
  </script>


  </body>
</html>
 <center>
  <h1>Saver</h1>
  <p>Please add a device to connect to here:</p>

   <button onclick="document.location='add.php'">Add a device</button>
 </center>
</body>
</html>