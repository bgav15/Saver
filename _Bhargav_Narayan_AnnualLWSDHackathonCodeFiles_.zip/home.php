<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<title>Saver</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
	 crossorigin="anonymous">
	<style>
  body {
  background-image: url('Energy.jpeg');
  background-repeat: no-repeat;
  background-size: cover;
}
    body {
  <p text="#ffffff">
}
		.content {
			display: none;
			margin: 1em;
		}
	</style>
</head>
<body>
  <body text="#ffffff" link="#000000" vlink="#000000"ƒ alink="#000000">
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<a class="navbar-brand" href="home.php">Saver</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="buy.php">Buy Devices</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="connect.php">Connect to Device(s)</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
    </ul>
  </div>
  </nav>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script>
    hideScreens();
    function hideScreens() {
      $(".content").hide();
    }
    $(document).ready(function() {
      $(".nav-link").on("click", function(){
        hideScreens();
        var target = $(this).attr("href");
        $(target).show();
        $(target).load("page_content/_" + target.replace("#","") + ".html");
      });

    });
  </script>
<center><h1>The Saver plug-ins</h1>
<h3>What <i>are</i> the Saver plug-ins?</h3>

<p>
The plug-ins are basically small devices that you can plug into any outlet that has another wire going into it. For example, if you want to see how much electricity your laptop uses per day, then your can just plug it in a socket, then plug the laptops wire into it, and then just connect the device in this website. Soon, you'll have the amount of electricty your fridge uses!</p></center>
  
   </body>
</html>